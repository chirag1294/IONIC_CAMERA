import { Component } from "@angular/core";
import { NavController, AlertController } from "ionic-angular";
import { Camera, CameraOptions } from "@ionic-native/camera";
import { AuthService } from "../../providers/auth-service/auth-service";
import { TextToSpeech } from '@ionic-native/text-to-speech';
import { TouchID } from '@ionic-native/touch-id';
@Component({
  selector: "page-home",
  templateUrl: "home.html"
})
export class HomePage {
  public photos: any;
  public base64Image: string;
  public fileImage: string;
  public responseData: any;
  userData = { user_id: "", token: "", imageB64: "" };
  constructor(
    public navCtrl: NavController,
    private camera: Camera,
    private alertCtrl: AlertController,
    public authService: AuthService,
    private touchId : TouchID)
     { }
  //const fileTransfer = this.transfer.create();

  ngOnInit() {
    this.photos = [];
  }

  deletePhoto(index) {
    let confirm = this.alertCtrl.create({
      title: "Sure you want to delete this photo?",
      message: "",
      buttons: [
        {
          text: "No",
          handler: () => 
          {
            console.log("Disagree clicked");
          }
        },
        {
          text: "Yes",
          handler: () =>
           {
            console.log("Agree clicked");
            this.photos.splice(index, 1);
          }
        }
      ]
    });
    confirm.present();
  }

  takePhoto() {
    console.log("coming here");

    const options: CameraOptions = {
      quality: 50,
      destinationType: this.camera.DestinationType.DATA_URL,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE,
      targetWidth: 450,
      targetHeight: 450,
      saveToPhotoAlbum: false
    };

    this.camera.getPicture(options).then(
      imageData => {
        this.base64Image = "data:image/jpeg;base64," + imageData;
        this.photos.push(this.base64Image);
        this.photos.reverse();
        this.sendData(imageData);
      },
      err => {
        console.log(err);
      }
    );
  }

  sendData(imageData) {
    this.userData.imageB64 = imageData;
    this.userData.user_id = "1";
    this.userData.token = "222";
    console.log(this.userData);
    this.authService.postData(this.userData, "userImage").then(
      result => {
        this.responseData = result;
      },
      err => {
        // Error log
      }
    );
  }
 /* tts()
  {
    this.tts.speak('Hello Chirag...')
  .then(() => console.log('Success'))
  .catch((reason: any) => console.log(reason));
  }*/
   touch()
 {
  this.touchId.isAvailable()
  .then(
    res => console.log('TouchID is available!'),
    err => console.error('TouchID is not available', err)
  );
this.touchId.verifyFingerprint('Scan your fingerprint please')
  .then(
    res => console.log('Ok', res),
    err => console.error('Error', err)
  );
 }
}
